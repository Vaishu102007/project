const { evaluateSubstitution } = require('./src/engine');

const scenarios = [
    {
        name: "Scenario 1: Typical Safe Substitution",
        patientId: "p2", // Jane Smith (No allergies)
        original: "d1", // Amoxicillin 500mg
        proposed: "d2", // Amox-Generic 500mg
        quantity: 5,
        expectedSafe: true
    },
    {
        name: "Scenario 2: Blocked due to Allergy",
        patientId: "p1", // John Doe (Allergic to Penicillin)
        original: "d1",
        proposed: "d2", // Amox-Generic (assuming rules flag this)
        quantity: 5,
        expectedSafe: false
    },
    {
        name: "Scenario 3: Blocked due to Missing Allergy Data",
        patientId: "p3", // Alice Johnson (Unknown allergies)
        original: "d1",
        proposed: "d2",
        quantity: 5,
        expectedSafe: false
    },
    {
        name: "Scenario 4: Operational Warning - Low Stock",
        patientId: "p2",
        original: "d5", // BrandX
        proposed: "d6", // GenericX (Stock 5)
        quantity: 5, // Just enough stock
        expectedSafe: true
    },
    {
        name: "Scenario 5: Operational Warning - Temperature Shift",
        patientId: "p2",
        original: "d1", // Amoxicillin (Not cold)
        proposed: "d3", // ColdMeds-A (Cold)
        quantity: 1,
        expectedSafe: false // Actually active ingredients don't match, so it will be blocked clinically!
    }
];

console.log("==========================================");
console.log("   SUBSTITUTION DECISION EXPERIMENT RUN   ");
console.log("==========================================\n");

let passed = 0;

scenarios.forEach(scenario => {
    const result = evaluateSubstitution(scenario.patientId, scenario.original, scenario.proposed, scenario.quantity);
    console.log(`Test: ${scenario.name}`);
    console.log(`  Patient: ${scenario.patientId}, Original: ${scenario.original}, Proposed: ${scenario.proposed}`);
    
    // For Scenario 2, my simple engine checks if the proposed name or ingredient contains the allergy string.
    // "Amox-Generic 500mg" doesn't contain "Penicillin". So it might incorrectly pass unless I add it to the allergy list.
    // Let's see what the engine actually outputs.
    
    console.log(`  Decision: ${result.canSubstitute ? 'APPROVED' : 'BLOCKED'}`);
    
    if (result.missingData.length > 0) console.log(`  Missing Data: ${result.missingData.join(', ')}`);
    if (result.clinicalWarnings.length > 0) console.log(`  Clinical Warnings: ${result.clinicalWarnings.join(' | ')}`);
    if (result.operationalWarnings.length > 0) console.log(`  Operational Warnings: ${result.operationalWarnings.join(' | ')}`);
    console.log("------------------------------------------");
});
