const express = require('express');
const cors = require('cors');
const routes = require('./src/routes');

const app = express();
const port = 3001;

app.use(cors());
app.use(express.json());

app.use('/api', routes);

app.listen(port, () => {
  console.log(`Specialty Clinic API listening at http://localhost:${port}`);
});
