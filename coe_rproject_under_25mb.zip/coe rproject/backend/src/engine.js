const patients = require('../data/patients.json');
const inventory = require('../data/inventory.json');

/**
 * Evaluates substitution validity.
 * @param {string} patientId 
 * @param {string} originalDrugId 
 * @param {string} proposedDrugId 
 * @param {number} requiredQuantity 
 * @returns {object} Decision result with warnings/blocks
 */
function evaluateSubstitution(patientId, originalDrugId, proposedDrugId, requiredQuantity = 1) {
    const result = {
        canSubstitute: true,
        clinicalWarnings: [],
        operationalWarnings: [],
        missingData: []
    };

    const patient = patients.find(p => p.id === patientId);
    if (!patient) {
        result.canSubstitute = false;
        result.missingData.push("Patient record not found.");
        return result;
    }

    const originalDrug = inventory.find(d => d.drugId === originalDrugId);
    const proposedDrug = inventory.find(d => d.drugId === proposedDrugId);

    if (!originalDrug || !proposedDrug) {
        result.canSubstitute = false;
        result.missingData.push("Drug records not found in inventory.");
        return result;
    }

    // 1. Clinical Rules
    if (originalDrug.activeIngredient !== proposedDrug.activeIngredient) {
        result.canSubstitute = false;
        result.clinicalWarnings.push("Active ingredients do not match.");
    }

    // 2. Patient Rules: Allergies based on drug classes
    if (patient.allergies.includes("Unknown")) {
        result.canSubstitute = false;
        result.clinicalWarnings.push("Patient allergy data is missing/unknown.");
        result.missingData.push("Allergies");
    } else {
        const proposedClasses = proposedDrug.drugClasses || [];
        for (const allergy of patient.allergies) {
            if (proposedClasses.includes(allergy) || 
                proposedDrug.name.toLowerCase().includes(allergy.toLowerCase()) || 
                proposedDrug.activeIngredient.toLowerCase().includes(allergy.toLowerCase())) {
                result.canSubstitute = false;
                result.clinicalWarnings.push(`Patient is allergic to ${allergy} (Detected in proposed substitute).`);
            }
        }
    }

    if (patient.adverseHistory.includes(proposedDrug.name)) {
        result.canSubstitute = false;
        result.clinicalWarnings.push(`Patient has a documented adverse history with ${proposedDrug.name}.`);
    }

    // Age / Pediatric constraints
    if (patient.age !== undefined && patient.age < 12 && !proposedDrug.pediatricApproved) {
        result.canSubstitute = false;
        result.clinicalWarnings.push("Proposed substitute is not approved for pediatric patients.");
    }

    // Geriatric constraints
    if (patient.age !== undefined && patient.age > 65 && proposedDrug.geriatricWarning) {
        result.clinicalWarnings.push("Caution: Proposed substitute has a geriatric use warning. Review dosage.");
        // We might not block it outright, but it's a strong clinical warning. Let's make it require override.
        result.canSubstitute = false;
    }


    // 3. Operational Rules
    if (proposedDrug.stock < requiredQuantity) {
        result.operationalWarnings.push(`Insufficient stock. Requested: ${requiredQuantity}, Available: ${proposedDrug.stock}`);
    } else if (proposedDrug.stock < requiredQuantity + 10) {
        result.operationalWarnings.push(`Low stock warning for proposed substitute.`);
    }

    if (proposedDrug.temperatureSensitive && !originalDrug.temperatureSensitive) {
        result.operationalWarnings.push("Operational Shift: Proposed substitute requires cold-chain handling, original did not.");
    }

    return result;
}

/**
 * Finds valid alternatives for a given prescription
 */
function findAlternatives(patientId, originalDrugId, requiredQuantity = 1) {
    const originalDrug = inventory.find(d => d.drugId === originalDrugId);
    if (!originalDrug) return [];

    return inventory.filter(d => d.drugId !== originalDrugId && d.activeIngredient === originalDrug.activeIngredient)
        .map(alt => {
            const evaluation = evaluateSubstitution(patientId, originalDrugId, alt.drugId, requiredQuantity);
            return {
                alternative: alt,
                evaluation: evaluation
            };
        });
}

module.exports = {
    evaluateSubstitution,
    findAlternatives
};
