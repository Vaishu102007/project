const express = require('express');
const { evaluateSubstitution, findAlternatives } = require('./engine');
const patients = require('../data/patients.json');
const inventory = require('../data/inventory.json');

const router = express.Router();

let metrics = {
    totalRequests: 0,
    substitutionsApproved: 0,
    substitutionsBlocked: 0,
    overrides: []
};

router.get('/patients', (req, res) => {
    res.json(patients);
});

router.get('/inventory', (req, res) => {
    res.json(inventory);
});

router.get('/metrics', (req, res) => {
    res.json(metrics);
});

router.post('/alternatives', (req, res) => {
    const { patientId, originalDrugId, requiredQuantity } = req.body;
    const alternatives = findAlternatives(patientId, originalDrugId, requiredQuantity);
    res.json(alternatives);
});

router.post('/substitute', (req, res) => {
    metrics.totalRequests++;
    const { patientId, originalDrugId, proposedDrugId, requiredQuantity, overrideReason } = req.body;
    
    const evaluation = evaluateSubstitution(patientId, originalDrugId, proposedDrugId, requiredQuantity);
    
    if (evaluation.canSubstitute || overrideReason) {
        if (overrideReason) {
            metrics.overrides.push({
                timestamp: new Date().toISOString(),
                patientId,
                originalDrugId,
                proposedDrugId,
                reason: overrideReason
            });
        }
        metrics.substitutionsApproved++;
        res.json({ success: true, evaluation, message: "Substitution processed." });
    } else {
        metrics.substitutionsBlocked++;
        res.status(400).json({ success: false, evaluation, message: "Substitution blocked due to clinical warnings." });
    }
});

module.exports = router;
