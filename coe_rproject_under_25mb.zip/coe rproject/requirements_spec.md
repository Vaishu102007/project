# Specialty Clinic Medicine Substitution Decision System
## Requirements Specification

### 1. Clinical Rules
Clinical validation ensures that any proposed medication substitution is medically safe and equivalent for the patient's condition.
*   **Active Ingredient Equivalence:** Substitutions must have the same active ingredient or an approved therapeutic equivalent.
*   **Dosage Match:** The substituted dosage must be equivalent or scalable (e.g., two 50mg tablets for one 100mg tablet).
*   **Formulation Constraints:** Do not substitute a slow-release formulation with an immediate-release formulation unless explicitly approved by a prescriber.
*   **Age/Weight Restrictions:** Certain substitutions may be contraindicated for pediatric or geriatric patients based on standard clinical guidelines.
*   **Prescriber Restrictions:** If a prescription is marked "Dispense As Written" (DAW) or "Do Not Substitute", no substitution is permitted.

### 2. Patient Rules
Patient-specific constraints that override general substitution rules.
*   **Allergy Check:** The substituted medication (including inactive ingredients/excipients) must be cross-referenced against the patient's documented allergy list.
*   **Adverse History:** If a patient has a documented history of adverse reactions or inefficacy with a specific brand/generic, it must be excluded from alternatives.
*   **Contraindications:** Check for drug-drug interactions if the patient is on other chronic medications.

### 3. Operational & Availability Rules
Rules governing the logistics and stock availability of substitutions.
*   **Stock Availability:** A substitution can only be proposed if current on-hand stock is sufficient to fulfill the entire prescription course.
*   **Temperature Sensitivity:** If a cold-chain medicine is substituted, the alternative must also be appropriately packaged, and the clinic must have the operational capacity to dispatch it securely.
*   **Cost Factor (Optional Warning):** If the substitution is significantly more expensive, provide an operational warning, but do not block the substitution clinically.

### 4. Workflow Rules
*   **Separation of Concerns:** UI must clearly distinguish between a **Clinical Warning** (e.g., patient allergy) and an **Operational Warning** (e.g., low stock).
*   **Human Confirmation:** All substitutions require a logged confirmation from a pharmacist or authorized clinician.
*   **Override Capture:** If a user overrides a system warning, a structured reason must be provided (e.g., "Consulted Prescriber", "Patient Consent").
