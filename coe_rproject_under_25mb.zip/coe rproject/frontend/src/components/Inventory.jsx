import React, { useState, useEffect } from 'react';
import { Package, Search, Thermometer, ShieldAlert, CheckCircle, AlertCircle } from 'lucide-react';

const API_BASE = 'http://localhost:3001/api';

export default function Inventory() {
    const [inventory, setInventory] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        fetch(`${API_BASE}/inventory`).then(r => r.json()).then(setInventory);
    }, []);

    const filteredInventory = inventory.filter(d => 
        d.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        d.activeIngredient.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="animate-fade-in">
            <h1 className="page-title">Pharmacy Inventory</h1>
            <p className="page-subtitle">Real-time stock tracking and drug classification metadata.</p>

            <div className="card-panel" style={{ marginBottom: '2rem' }}>
                <div className="form-group input-with-icon" style={{ maxWidth: '400px', marginBottom: '1.5rem' }}>
                    <div className="input-wrapper">
                        <Search className="input-icon" size={18} />
                        <input
                            type="text"
                            placeholder="Search by Drug Name or Active Ingredient..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>

                <div style={{ overflowX: 'auto' }}>
                    <table>
                        <thead>
                            <tr>
                                <th>Drug ID</th>
                                <th>Name & Formulation</th>
                                <th>Active Ingredient</th>
                                <th>Drug Class</th>
                                <th>Flags</th>
                                <th>Stock Level</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredInventory.length === 0 ? (
                                <tr>
                                    <td colSpan="6" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>
                                        No inventory items found matching your search.
                                    </td>
                                </tr>
                            ) : (
                                filteredInventory.map(d => (
                                    <tr key={d.drugId}>
                                        <td style={{ fontWeight: 600, color: 'var(--text-secondary)' }}>{d.drugId}</td>
                                        <td style={{ fontWeight: 600, color: 'var(--text-primary)' }}>{d.name}</td>
                                        <td>{d.activeIngredient}</td>
                                        <td>
                                            <span style={{ 
                                                background: '#f1f5f9', 
                                                color: 'var(--text-secondary)', 
                                                padding: '0.25rem 0.5rem', 
                                                borderRadius: '4px', 
                                                fontSize: '0.8rem',
                                                fontWeight: 500
                                            }}>
                                                {d.drugClasses.join(', ')}
                                            </span>
                                        </td>
                                        <td>
                                            <div style={{ display: 'flex', gap: '0.5rem' }}>
                                                {d.temperatureSensitive && <Thermometer size={16} color="#0ea5e9" title="Temperature Sensitive" />}
                                                {d.pediatricApproved && <CheckCircle size={16} color="var(--success)" title="Pediatric Approved" />}
                                                {d.geriatricWarning && <ShieldAlert size={16} color="var(--warning)" title="Geriatric Warning" />}
                                            </div>
                                        </td>
                                        <td>
                                            {d.stock > 50 ? (
                                                <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', color: 'var(--success)', fontWeight: 600 }}>
                                                    <CheckCircle size={16} /> {d.stock}
                                                </span>
                                            ) : d.stock > 10 ? (
                                                <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', color: 'var(--warning)', fontWeight: 600 }}>
                                                    <AlertCircle size={16} /> {d.stock}
                                                </span>
                                            ) : (
                                                <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', color: 'var(--danger)', fontWeight: 600 }}>
                                                    <AlertCircle size={16} /> {d.stock} (Low)
                                                </span>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
