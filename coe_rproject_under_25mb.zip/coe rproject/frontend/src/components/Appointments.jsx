import React from 'react';
import { Calendar, Clock, User, CheckCircle, MoreHorizontal } from 'lucide-react';

const mockAppointments = [
  { id: 1, time: '09:00 AM', patient: 'Sarah Jenkins', type: 'Annual Checkup', status: 'Confirmed', dr: 'Dr. Smith' },
  { id: 2, time: '10:30 AM', patient: 'Michael Chang', type: 'Post-op Review', status: 'In Waiting Room', dr: 'Dr. Smith' },
  { id: 3, time: '11:15 AM', patient: 'Emily Rodriguez', type: 'Consultation', status: 'In Progress', dr: 'Dr. Smith' },
  { id: 4, time: '01:00 PM', patient: 'Robert Davis', type: 'Follow-up', status: 'Confirmed', dr: 'Dr. Smith' },
];

export default function Appointments() {
  return (
    <div className="animate-fade-in">
      <h1 className="page-title">Appointments Schedule</h1>
      <p className="page-subtitle">Manage today's clinical visits and patient flow.</p>
      
      <div className="card-panel">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
          <h3 style={{ fontSize: '1.25rem', fontWeight: 600 }}>Today - Oct 24, 2026</h3>
          <button style={{ padding: '0.5rem 1rem', fontSize: '0.875rem' }}>+ New Appointment</button>
        </div>
        
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {mockAppointments.map(app => (
            <div key={app.id} style={{ 
              display: 'flex', 
              alignItems: 'center', 
              justifyContent: 'space-between', 
              padding: '1.25rem', 
              background: 'rgba(15, 23, 42, 0.4)', 
              borderRadius: '8px',
              borderLeft: `4px solid ${app.status === 'In Waiting Room' ? 'var(--warning)' : app.status === 'In Progress' ? 'var(--primary-color)' : 'var(--success)'}`
            }}>
              <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center' }}>
                <div style={{ fontWeight: 600, color: 'var(--text-primary)', display: 'flex', alignItems: 'center', gap: '0.5rem', minWidth: '90px' }}>
                  <Clock size={16} color="var(--text-secondary)" /> {app.time}
                </div>
                <div>
                  <div style={{ fontWeight: 600, fontSize: '1.1rem' }}>{app.patient}</div>
                  <div style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>{app.type}</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: '1.5rem', alignItems: 'center' }}>
                <span style={{ 
                  padding: '0.25rem 0.75rem', 
                  borderRadius: '20px', 
                  fontSize: '0.875rem', 
                  fontWeight: 500,
                  background: app.status === 'In Waiting Room' ? 'var(--warning-bg)' : app.status === 'In Progress' ? 'rgba(56, 189, 248, 0.1)' : 'var(--success-bg)',
                  color: app.status === 'In Waiting Room' ? 'var(--warning)' : app.status === 'In Progress' ? 'var(--primary-color)' : 'var(--success)'
                }}>
                  {app.status}
                </span>
                <button style={{ background: 'transparent', padding: '0.5rem', color: 'var(--text-secondary)' }}>
                  <MoreHorizontal size={20} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
