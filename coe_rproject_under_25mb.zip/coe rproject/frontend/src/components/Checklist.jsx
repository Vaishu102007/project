import React, { useState, useEffect } from 'react';
import { AlertCircle, AlertTriangle, CheckCircle, Info, User, Pill, ArrowRight, ShieldAlert } from 'lucide-react';

const API_BASE = 'http://localhost:3001/api';

export default function Checklist() {
    const [patients, setPatients] = useState([]);
    const [inventory, setInventory] = useState([]);
    
    const [patientId, setPatientId] = useState('');
    const [originalDrugId, setOriginalDrugId] = useState('');
    const [quantity, setQuantity] = useState(1);
    
    const [alternatives, setAlternatives] = useState([]);
    const [selectedAlternative, setSelectedAlternative] = useState(null);
    const [overrideReason, setOverrideReason] = useState('');
    const [submissionStatus, setSubmissionStatus] = useState(null);
    const [hasSearched, setHasSearched] = useState(false);

    useEffect(() => {
        fetch(`${API_BASE}/patients`).then(r => r.json()).then(setPatients);
        fetch(`${API_BASE}/inventory`).then(r => r.json()).then(setInventory);
    }, []);

    const findAlternatives = async () => {
        if (!patientId || !originalDrugId) return;
        setSubmissionStatus(null);
        setSelectedAlternative(null);
        setHasSearched(false);
        const res = await fetch(`${API_BASE}/alternatives`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ patientId, originalDrugId, requiredQuantity: quantity })
        });
        const data = await res.json();
        setAlternatives(data);
        setHasSearched(true);
    };

    const submitSubstitution = async (alt) => {
        const payload = {
            patientId,
            originalDrugId,
            proposedDrugId: alt.alternative.drugId,
            requiredQuantity: quantity,
            overrideReason: alt.evaluation.canSubstitute ? null : overrideReason
        };

        const res = await fetch(`${API_BASE}/substitute`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        setSubmissionStatus(data);
        if (data.success) {
            setOverrideReason('');
        }
    };

    const selectedPatient = patients.find(p => p.id === patientId);
    const selectedDrug = inventory.find(d => d.drugId === originalDrugId);

    return (
        <div className="animate-fade-in">
            <h1 className="page-title">Medicine Substitution Tool</h1>
            <p className="page-subtitle">Evaluate safe alternatives based on Ann Hospitals clinical guidelines.</p>

            <div className="card-panel" style={{ marginBottom: '2rem' }}>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem' }}>
                    
                    {/* Patient Selection */}
                    <div className="form-group">
                        <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}><User size={16} color="var(--primary-color)"/> Select Patient Profile</label>
                        <select value={patientId} onChange={e => setPatientId(e.target.value)}>
                            <option value="">-- Search Registry --</option>
                            {patients.map(p => <option key={p.id} value={p.id}>{p.name} (MRN: {p.id})</option>)}
                        </select>
                        {selectedPatient && (
                            <div style={{ marginTop: '0.75rem', padding: '1rem', background: '#f8fafc', border: '1px solid var(--border-color)', borderRadius: '6px', fontSize: '0.875rem' }}>
                                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', marginBottom: '0.5rem' }}>
                                    <div><span style={{ color: 'var(--text-secondary)' }}>Age:</span> <strong>{selectedPatient.age} yrs</strong></div>
                                    <div><span style={{ color: 'var(--text-secondary)' }}>Weight:</span> <strong>{selectedPatient.weightKg} kg</strong></div>
                                </div>
                                <div style={{ paddingTop: '0.5rem', borderTop: '1px solid var(--border-color)' }}>
                                    <span style={{ color: 'var(--text-secondary)' }}>Allergies: </span> 
                                    <strong style={{ color: selectedPatient.allergies.length ? 'var(--danger)' : 'var(--text-primary)' }}>
                                        {selectedPatient.allergies.length ? selectedPatient.allergies.join(', ') : 'None Documented'}
                                    </strong>
                                </div>
                            </div>
                        )}
                    </div>
                    
                    {/* Drug Selection */}
                    <div className="form-group">
                        <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}><Pill size={16} color="var(--primary-color)"/> Original Prescription (Unavailable)</label>
                        <select value={originalDrugId} onChange={e => setOriginalDrugId(e.target.value)}>
                            <option value="">-- Select Medication --</option>
                            {inventory.map(d => <option key={d.drugId} value={d.drugId}>{d.name}</option>)}
                        </select>
                        {selectedDrug && (
                            <div style={{ marginTop: '0.75rem', padding: '1rem', background: '#f8fafc', border: '1px solid var(--border-color)', borderRadius: '6px', fontSize: '0.875rem' }}>
                                <div style={{ marginBottom: '0.5rem' }}><span style={{ color: 'var(--text-secondary)' }}>Active:</span> <strong>{selectedDrug.activeIngredient}</strong></div>
                                <div><span style={{ color: 'var(--text-secondary)' }}>Class:</span> <strong>{selectedDrug.drugClasses?.join(', ')}</strong></div>
                            </div>
                        )}
                    </div>

                    {/* Quantity & Action */}
                    <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'flex-start' }}>
                        <div className="form-group">
                            <label>Quantity Required</label>
                            <input type="number" min="1" value={quantity} onChange={e => setQuantity(parseInt(e.target.value) || 1)} 
                                   style={{ fontSize: '1.1rem', padding: '0.75rem' }} />
                        </div>
                        
                        <button onClick={findAlternatives} disabled={!patientId || !originalDrugId} 
                                style={{ marginTop: 'auto', padding: '1rem', fontSize: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.5rem' }}>
                            Evaluate Alternatives <ArrowRight size={18} />
                        </button>
                    </div>
                </div>
            </div>

            {hasSearched && alternatives.length === 0 && (
                <div className="alert warning animate-fade-in" style={{ marginTop: '2rem', padding: '1.5rem' }}>
                    <Info size={28} className="alert-icon"/>
                    <div style={{ paddingLeft: '0.5rem' }}>
                        <strong style={{ fontSize: '1.1rem' }}>No Alternatives Available</strong>
                        <div style={{ marginTop: '0.25rem', opacity: 0.9 }}>
                            There are currently no medications in inventory with the same active ingredient ({selectedDrug?.activeIngredient}) to substitute.
                        </div>
                    </div>
                </div>
            )}

            {alternatives.length > 0 && (
                <div className="animate-fade-in">
                    <h3 style={{ marginBottom: '1rem', fontWeight: 600, fontSize: '1.25rem', color: 'var(--text-primary)' }}>Proposed Clinical Alternatives</h3>
                    
                    {alternatives.map((alt, idx) => (
                        <div key={idx} className="card-panel" style={{ 
                            marginBottom: '1.5rem',
                            borderLeft: `4px solid ${alt.evaluation.canSubstitute ? 'var(--success)' : 'var(--danger)'}`
                        }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem', paddingBottom: '1rem', borderBottom: '1px solid var(--border-color)' }}>
                                <div>
                                    <h4 style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--text-primary)', marginBottom: '0.25rem' }}>{alt.alternative.name}</h4>
                                    <div style={{ fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                                        Inventory ID: {alt.alternative.drugId} &bull; Current Stock: <strong>{alt.alternative.stock} units</strong>
                                    </div>
                                </div>
                                {alt.evaluation.canSubstitute ? 
                                    <span style={{ color: 'var(--success)', display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 600, background: 'var(--success-bg)', padding: '0.5rem 1rem', borderRadius: '20px', fontSize: '0.875rem' }}><CheckCircle size={18}/> Clinically Safe</span> : 
                                    <span style={{ color: 'var(--danger)', display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 600, background: 'var(--danger-bg)', padding: '0.5rem 1rem', borderRadius: '20px', fontSize: '0.875rem' }}><ShieldAlert size={18}/> Blocked</span>
                                }
                            </div>

                            <div style={{ display: 'flex', flexDirection: 'column' }}>
                                {alt.evaluation.missingData.length > 0 && (
                                    <div className="alert danger">
                                        <AlertTriangle size={20} className="alert-icon"/>
                                        <div>
                                            <strong>Action Required - Missing Data: </strong>
                                            {alt.evaluation.missingData.join(', ')}
                                        </div>
                                    </div>
                                )}

                                {alt.evaluation.clinicalWarnings.map((w, i) => (
                                    <div key={i} className="alert danger">
                                        <AlertCircle size={20} className="alert-icon"/>
                                        <div><strong>Clinical Alert:</strong> {w}</div>
                                    </div>
                                ))}

                                {alt.evaluation.operationalWarnings.map((w, i) => (
                                    <div key={i} className="alert warning">
                                        <Info size={20} className="alert-icon"/>
                                        <div><strong>Operational Notice:</strong> {w}</div>
                                    </div>
                                ))}
                            </div>

                            {/* Human Confirmation & Override Workflow */}
                            <div style={{ marginTop: '1.5rem', display: 'flex', gap: '1rem', alignItems: 'center', background: '#f8fafc', padding: '1rem', borderRadius: '6px' }}>
                                {!alt.evaluation.canSubstitute && (
                                    <select 
                                        style={{ flex: 1, background: 'white' }} 
                                        value={selectedAlternative === alt ? overrideReason : ''}
                                        onChange={e => {
                                            setSelectedAlternative(alt);
                                            setOverrideReason(e.target.value);
                                        }}
                                    >
                                        <option value="">-- Select Required Override Reason --</option>
                                        <option value="Consulted Prescriber (Approved)">Consulted Prescriber (Approved)</option>
                                        <option value="Patient Consent Verified">Patient Consent Verified</option>
                                        <option value="Emergency Protocol Authorized">Emergency Protocol Authorized</option>
                                        {alt.evaluation.missingData.includes('Allergies') && <option value="Patient confirmed no allergies verbally">Verified: No Allergies</option>}
                                    </select>
                                )}
                                
                                <button 
                                    disabled={!alt.evaluation.canSubstitute && (selectedAlternative !== alt || !overrideReason)}
                                    onClick={() => submitSubstitution(alt)}
                                    style={{ 
                                        background: alt.evaluation.canSubstitute ? 'var(--success)' : 'var(--warning)',
                                        color: alt.evaluation.canSubstitute ? 'white' : 'white',
                                        flex: alt.evaluation.canSubstitute ? 1 : 'none',
                                        padding: '0.75rem 2rem'
                                    }}
                                >
                                    {alt.evaluation.canSubstitute ? "Confirm Safe Substitution" : "Override Block & Substitute"}
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {submissionStatus && (
                <div className={`alert ${submissionStatus.success ? 'success' : 'danger'} animate-fade-in`} style={{ marginTop: '2rem' }}>
                    {submissionStatus.success ? <CheckCircle size={24} className="alert-icon"/> : <AlertCircle size={24} className="alert-icon"/>}
                    <div style={{ paddingLeft: '0.5rem' }}>
                        <strong style={{ fontSize: '1.1rem' }}>{submissionStatus.success ? 'Decision Logged in EHR' : 'Decision Blocked'}</strong>
                        <div style={{ marginTop: '0.25rem' }}>{submissionStatus.message}</div>
                    </div>
                </div>
            )}

        </div>
    );
}
