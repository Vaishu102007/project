import React, { useState, useEffect } from 'react';
import { Activity, Database, CheckCircle, XCircle } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const API_BASE = 'http://localhost:3001/api';

// Static mock data to simulate historical volume over the last 7 days for the chart
const mockHistoricalData = [
  { name: 'Mon', Safe: 45, Overrides: 12, Blocked: 5 },
  { name: 'Tue', Safe: 52, Overrides: 14, Blocked: 3 },
  { name: 'Wed', Safe: 38, Overrides: 8,  Blocked: 6 },
  { name: 'Thu', Safe: 65, Overrides: 19, Blocked: 2 },
  { name: 'Fri', Safe: 48, Overrides: 15, Blocked: 8 },
  { name: 'Sat', Safe: 22, Overrides: 5,  Blocked: 1 },
  { name: 'Sun', Safe: 28, Overrides: 7,  Blocked: 2 },
];

export default function Dashboard() {
    const [metrics, setMetrics] = useState({
        totalRequests: 0,
        substitutionsApproved: 0,
        substitutionsBlocked: 0,
        overrides: []
    });

    // Combine mock historical data with today's live session data
    // Assuming 'Today' is the sum of live metrics
    const [chartData, setChartData] = useState(mockHistoricalData);

    useEffect(() => {
        const fetchMetrics = () => {
            fetch(`${API_BASE}/metrics`)
                .then(r => r.json())
                .then(data => {
                    setMetrics(data);
                    
                    // Update the "Today" slice in chart data based on live metrics
                    // Safe = Approved minus Overrides. 
                    // (Assuming all overrides are the forced ones, approved includes pure safe ones)
                    const liveOverridesCount = data.overrides.length;
                    const liveSafeCount = Math.max(0, data.substitutionsApproved - liveOverridesCount);
                    
                    const updatedChartData = [...mockHistoricalData];
                    updatedChartData.push({
                        name: 'Today (Live)',
                        Safe: liveSafeCount,
                        Overrides: liveOverridesCount,
                        Blocked: data.substitutionsBlocked
                    });
                    setChartData(updatedChartData);
                });
        };
        fetchMetrics();
        const interval = setInterval(fetchMetrics, 2000);
        return () => clearInterval(interval);
    }, []);

    return (
        <div className="animate-fade-in">
            <h1 className="page-title">System Metrics</h1>
            <p className="page-subtitle">Real-time overview of Ann Hospitals substitution workflows and historical trends.</p>
            
            <div className="dashboard-grid">
                <div className="card-panel stat-card">
                    <div className="stat-header">
                        <div className="stat-icon" style={{ background: '#f0f9ff', color: '#0ea5e9' }}>
                            <Database size={24} />
                        </div>
                    </div>
                    <div className="stat-value">{metrics.totalRequests}</div>
                    <div className="stat-label">Total Session Requests</div>
                </div>
                
                <div className="card-panel stat-card">
                    <div className="stat-header">
                        <div className="stat-icon" style={{ background: 'var(--success-bg)', color: 'var(--success)' }}>
                            <CheckCircle size={24} />
                        </div>
                    </div>
                    <div className="stat-value">{metrics.substitutionsApproved}</div>
                    <div className="stat-label">Approved (Safe or Overridden)</div>
                </div>
                
                <div className="card-panel stat-card">
                    <div className="stat-header">
                        <div className="stat-icon" style={{ background: 'var(--danger-bg)', color: 'var(--danger)' }}>
                            <XCircle size={24} />
                        </div>
                    </div>
                    <div className="stat-value">{metrics.substitutionsBlocked}</div>
                    <div className="stat-label">Blocked Substitutions</div>
                </div>
            </div>

            {/* Data Visualization Section */}
            <div className="card-panel" style={{ marginBottom: '2rem', padding: '1.5rem 2rem' }}>
                <h3 style={{ marginBottom: '1.5rem', fontWeight: 600, fontSize: '1.25rem', color: 'var(--text-primary)' }}>Substitution Trends (Last 7 Days)</h3>
                <div style={{ width: '100%', height: 350 }}>
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                            data={chartData}
                            margin={{ top: 10, right: 30, left: 0, bottom: 0 }}
                        >
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                            <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b'}} dy={10} />
                            <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b'}} />
                            <Tooltip 
                                contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)' }}
                                cursor={{fill: '#f1f5f9'}}
                            />
                            <Legend wrapperStyle={{ paddingTop: '15px' }} />
                            <Bar dataKey="Safe" stackId="a" fill="var(--success)" radius={[0, 0, 4, 4]} />
                            <Bar dataKey="Overrides" stackId="a" fill="var(--warning)" />
                            <Bar dataKey="Blocked" stackId="a" fill="var(--danger)" radius={[4, 4, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>

            {/* Audit Log Table */}
            <h3 style={{ marginBottom: '1rem', fontWeight: 600, fontSize: '1.25rem', color: 'var(--text-primary)' }}>Recent Overrides Audit Log</h3>
            <div className="card-panel" style={{ padding: 0, overflow: 'hidden' }}>
                {metrics.overrides.length === 0 ? (
                    <div style={{ padding: '2rem', color: 'var(--text-secondary)', textAlign: 'center' }}>
                        No clinical overrides recorded in the current session.
                    </div>
                ) : (
                    <div style={{ overflowX: 'auto' }}>
                        <table>
                            <thead>
                                <tr>
                                    <th>Timestamp</th>
                                    <th>MRN (Patient ID)</th>
                                    <th>Original Order</th>
                                    <th>Proposed Substitute</th>
                                    <th>Override Reason Logged</th>
                                </tr>
                            </thead>
                            <tbody>
                                {metrics.overrides.slice().reverse().map((ov, idx) => (
                                    <tr key={idx}>
                                        <td>{new Date(ov.timestamp).toLocaleTimeString()}</td>
                                        <td style={{ fontWeight: 600 }}>{ov.patientId}</td>
                                        <td>{ov.originalDrugId}</td>
                                        <td>{ov.proposedDrugId}</td>
                                        <td>
                                            <span style={{ 
                                                background: 'var(--warning-bg)', 
                                                color: '#92400e', 
                                                padding: '0.25rem 0.75rem', 
                                                borderRadius: '20px', 
                                                fontSize: '0.875rem',
                                                fontWeight: 500,
                                                display: 'inline-block'
                                            }}>
                                                {ov.reason}
                                            </span>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
}
