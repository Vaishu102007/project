import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

const mockStaff = [
  { id: 1, name: 'Dr. Rebecca Adams', role: 'Chief of Surgery', dept: 'Surgery', email: 'r.adams@ann.org', phone: 'Ext 4012' },
  { id: 2, name: 'Dr. William Chen', role: 'Attending Physician', dept: 'Internal Medicine', email: 'w.chen@ann.org', phone: 'Ext 3099' },
  { id: 3, name: 'Sarah Jenkins, RN', role: 'Head Nurse', dept: 'ICU', email: 's.jenkins@ann.org', phone: 'Ext 2050' },
  { id: 4, name: 'Dr. A. Smith', role: 'Clinical Pharmacist', dept: 'Pharmacy', email: 'a.smith@ann.org', phone: 'Ext 5501' },
];

export default function StaffDirectory() {
  return (
    <div className="animate-fade-in">
      <h1 className="page-title">Staff Directory</h1>
      <p className="page-subtitle">Find contact information for Ann Hospitals personnel.</p>
      
      <div className="dashboard-grid">
        {mockStaff.map(staff => (
          <div key={staff.id} className="card-panel" style={{ display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
              <div style={{ width: '50px', height: '50px', borderRadius: '50%', background: 'rgba(56, 189, 248, 0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--primary-color)', fontSize: '1.25rem', fontWeight: 600 }}>
                {staff.name.charAt(0)}
              </div>
              <div>
                <h3 style={{ fontSize: '1.1rem', fontWeight: 600, color: 'var(--text-primary)' }}>{staff.name}</h3>
                <p style={{ color: 'var(--primary-color)', fontSize: '0.875rem', fontWeight: 500 }}>{staff.role}</p>
              </div>
            </div>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem', fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <MapPin size={16} /> {staff.dept} Department
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Mail size={16} /> {staff.email}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Phone size={16} /> {staff.phone}
              </div>
            </div>
            
            <button style={{ marginTop: '1.5rem', width: '100%', background: 'rgba(15, 23, 42, 0.5)', color: 'var(--text-primary)' }}>
              Message
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
