import React from 'react';
import { FlaskConical, AlertTriangle, CheckCircle, Download } from 'lucide-react';

const mockLabs = [
  { id: 'L-1029', patient: 'John Doe', date: 'Oct 23, 2026', test: 'Complete Blood Count (CBC)', status: 'Abnormal', critical: true },
  { id: 'L-1028', patient: 'Alice Johnson', date: 'Oct 22, 2026', test: 'Lipid Panel', status: 'Normal', critical: false },
  { id: 'L-1027', patient: 'Bobby Tables', date: 'Oct 21, 2026', test: 'Metabolic Panel', status: 'Pending', critical: false },
];

export default function LabResults() {
  return (
    <div className="animate-fade-in">
      <h1 className="page-title">Lab Results Viewer</h1>
      <p className="page-subtitle">Review recent diagnostic tests and pathology reports.</p>
      
      <div className="dashboard-grid" style={{ marginBottom: '2rem' }}>
        {mockLabs.map(lab => (
          <div key={lab.id} className="card-panel" style={{ borderTop: lab.critical ? '4px solid var(--danger)' : '1px solid var(--border-color)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '1rem' }}>
              <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                <FlaskConical size={20} color="var(--primary-color)" />
                <span style={{ fontWeight: 600 }}>{lab.id}</span>
              </div>
              <span style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>{lab.date}</span>
            </div>
            <h3 style={{ fontSize: '1.25rem', marginBottom: '0.25rem' }}>{lab.patient}</h3>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '1.5rem' }}>{lab.test}</p>
            
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ 
                display: 'flex', gap: '0.5rem', alignItems: 'center', fontWeight: 600,
                color: lab.status === 'Abnormal' ? 'var(--danger)' : lab.status === 'Normal' ? 'var(--success)' : 'var(--warning)'
              }}>
                {lab.status === 'Abnormal' ? <AlertTriangle size={16} /> : lab.status === 'Normal' ? <CheckCircle size={16} /> : null}
                {lab.status}
              </span>
              <button style={{ background: 'rgba(56, 189, 248, 0.1)', color: 'var(--primary-color)', padding: '0.5rem 1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <Download size={16} /> View
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
