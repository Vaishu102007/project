import React from 'react';
import { MessageSquare, Star, Search } from 'lucide-react';

const mockMessages = [
  { id: 1, sender: 'Dr. Rebecca Adams', subject: 'Patient Consult: Bobby Tables', time: '10:45 AM', unread: true },
  { id: 2, sender: 'Pharmacy Dept', subject: 'Out of Stock Alert: Mab-Alpha', time: '09:15 AM', unread: true },
  { id: 3, sender: 'Admin Office', subject: 'Updated Clinical Guidelines Q4', time: 'Yesterday', unread: false },
  { id: 4, sender: 'Nurse Joy', subject: 'Follow-up on John Doe labs', time: 'Oct 22', unread: false },
];

export default function Messages() {
  return (
    <div className="animate-fade-in">
      <h1 className="page-title">Secure Messaging</h1>
      <p className="page-subtitle">Internal clinical communications (HIPAA Compliant).</p>
      
      <div className="card-panel" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ padding: '1.5rem', borderBottom: '1px solid var(--border-color)', display: 'flex', gap: '1rem', alignItems: 'center' }}>
          <div className="input-wrapper" style={{ flex: 1 }}>
            <Search className="input-icon" size={18} />
            <input type="text" placeholder="Search messages..." />
          </div>
          <button style={{ padding: '0.75rem 1.5rem' }}>Compose</button>
        </div>
        
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {mockMessages.map(msg => (
            <div key={msg.id} style={{ 
              display: 'flex', 
              alignItems: 'center', 
              padding: '1.25rem 1.5rem', 
              borderBottom: '1px solid var(--border-color)',
              background: msg.unread ? 'rgba(56, 189, 248, 0.05)' : 'transparent',
              cursor: 'pointer',
              transition: 'background 0.2s'
            }}>
              <div style={{ width: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <Star size={18} color={msg.unread ? "var(--primary-color)" : "var(--text-secondary)"} fill={msg.unread ? "var(--primary-color)" : "none"} />
              </div>
              <div style={{ width: '200px', fontWeight: msg.unread ? 600 : 400, color: msg.unread ? 'var(--text-primary)' : 'var(--text-secondary)' }}>
                {msg.sender}
              </div>
              <div style={{ flex: 1, fontWeight: msg.unread ? 600 : 400, color: 'var(--text-primary)' }}>
                {msg.subject}
              </div>
              <div style={{ width: '100px', textAlign: 'right', fontSize: '0.875rem', color: 'var(--text-secondary)' }}>
                {msg.time}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
