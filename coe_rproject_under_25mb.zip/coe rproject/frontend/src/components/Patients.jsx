import React, { useState, useEffect } from 'react';
import { Search, User, Activity, AlertTriangle } from 'lucide-react';

const API_BASE = 'http://localhost:3001/api';

export default function Patients() {
    const [patients, setPatients] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        fetch(`${API_BASE}/patients`).then(r => r.json()).then(setPatients);
    }, []);

    const filteredPatients = patients.filter(p => 
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        p.id.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className="animate-fade-in">
            <h1 className="page-title">Patient Registry</h1>
            <p className="page-subtitle">View and manage patient demographics and clinical history.</p>

            <div className="card-panel" style={{ marginBottom: '2rem' }}>
                <div className="form-group input-with-icon" style={{ maxWidth: '400px', marginBottom: '1.5rem' }}>
                    <div className="input-wrapper">
                        <Search className="input-icon" size={18} />
                        <input
                            type="text"
                            placeholder="Search by Name or MRN..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                </div>

                <div style={{ overflowX: 'auto' }}>
                    <table>
                        <thead>
                            <tr>
                                <th>MRN</th>
                                <th>Patient Name</th>
                                <th>Age</th>
                                <th>Weight (kg)</th>
                                <th>Allergies / Alerts</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredPatients.length === 0 ? (
                                <tr>
                                    <td colSpan="5" style={{ textAlign: 'center', padding: '2rem', color: 'var(--text-secondary)' }}>
                                        No patients found matching your search.
                                    </td>
                                </tr>
                            ) : (
                                filteredPatients.map(p => (
                                    <tr key={p.id}>
                                        <td style={{ fontWeight: 600, color: 'var(--text-secondary)' }}>{p.id}</td>
                                        <td style={{ fontWeight: 500 }}>
                                            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                                                <div style={{ background: '#f1f5f9', padding: '0.4rem', borderRadius: '50%', color: 'var(--primary-color)' }}>
                                                    <User size={16} />
                                                </div>
                                                {p.name}
                                            </div>
                                        </td>
                                        <td>{p.age} yrs</td>
                                        <td>{p.weightKg} kg</td>
                                        <td>
                                            {p.allergies.length > 0 ? (
                                                <span style={{ 
                                                    background: 'var(--danger-bg)', 
                                                    color: 'var(--danger)', 
                                                    padding: '0.25rem 0.75rem', 
                                                    borderRadius: '20px', 
                                                    fontSize: '0.875rem',
                                                    fontWeight: 500,
                                                    display: 'inline-flex',
                                                    alignItems: 'center',
                                                    gap: '0.25rem'
                                                }}>
                                                    <AlertTriangle size={14} /> {p.allergies.join(', ')}
                                                </span>
                                            ) : (
                                                <span style={{ color: 'var(--text-secondary)', fontSize: '0.875rem' }}>None Documented</span>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}
