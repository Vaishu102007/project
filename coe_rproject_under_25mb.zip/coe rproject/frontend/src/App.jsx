import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  ShieldCheck, 
  LogOut, 
  Settings, 
  LayoutDashboard, 
  Stethoscope, 
  Users, 
  Package,
  Calendar,
  FlaskConical,
  MessageSquare,
  Contact
} from 'lucide-react';
import Checklist from './components/Checklist';
import Dashboard from './components/Dashboard';
import Patients from './components/Patients';
import Inventory from './components/Inventory';
import Appointments from './components/Appointments';
import LabResults from './components/LabResults';
import Messages from './components/Messages';
import StaffDirectory from './components/StaffDirectory';
import Login from './components/Login';
import './index.css';

function Sidebar({ onLogout }) {
  const location = useLocation();
  return (
    <aside className="sidebar">
      <div className="brand-header">
        <Stethoscope size={28} color="var(--primary-color)" />
        <div>
          <h1>Ann Hospitals</h1>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>Clinical Portal</div>
        </div>
      </div>
      
      <div style={{ overflowY: 'auto', flex: 1 }}>
        <nav className="nav-menu">
          <Link to="/" className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}>
            <ShieldCheck size={20} />
            <span>Substitution Tool</span>
          </Link>
          <Link to="/appointments" className={`nav-link ${location.pathname === '/appointments' ? 'active' : ''}`}>
            <Calendar size={20} />
            <span>Schedule</span>
          </Link>
          <Link to="/patients" className={`nav-link ${location.pathname === '/patients' ? 'active' : ''}`}>
            <Users size={20} />
            <span>Patient Registry</span>
          </Link>
          <Link to="/labs" className={`nav-link ${location.pathname === '/labs' ? 'active' : ''}`}>
            <FlaskConical size={20} />
            <span>Lab Results</span>
          </Link>
          <Link to="/inventory" className={`nav-link ${location.pathname === '/inventory' ? 'active' : ''}`}>
            <Package size={20} />
            <span>Pharmacy</span>
          </Link>
          <Link to="/dashboard" className={`nav-link ${location.pathname === '/dashboard' ? 'active' : ''}`}>
            <LayoutDashboard size={20} />
            <span>System Metrics</span>
          </Link>
          
          <div style={{ padding: '1rem 1.5rem', fontSize: '0.75rem', fontWeight: 600, color: 'var(--text-secondary)', marginTop: '1rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Communications
          </div>
          <Link to="/messages" className={`nav-link ${location.pathname === '/messages' ? 'active' : ''}`}>
            <MessageSquare size={20} />
            <span>Secure Inbox</span>
          </Link>
          <Link to="/staff" className={`nav-link ${location.pathname === '/staff' ? 'active' : ''}`}>
            <Contact size={20} />
            <span>Staff Directory</span>
          </Link>
        </nav>
      </div>

      <div className="sidebar-footer">
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.75rem', cursor: 'pointer' }}>
          <Settings size={16} /> Settings
        </div>
        <div 
          style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--danger)', cursor: 'pointer' }}
          onClick={onLogout}
        >
          <LogOut size={16} /> Logout
        </div>
      </div>
    </aside>
  );
}

function Topbar({ user }) {
  return (
    <header className="topbar">
      <div className="user-profile">
        <span>{user?.name || "Dr. A. Smith, PharmD"}</span>
        <div className="user-avatar">{user?.initials || "AS"}</div>
      </div>
    </header>
  );
}

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);

  const handleLogin = (email) => {
    setIsAuthenticated(true);
    let name = email.split('@')[0];
    name = name.charAt(0).toUpperCase() + name.slice(1);
    setUser({
      name: `Dr. ${name}`,
      initials: name.substring(0, 2).toUpperCase()
    });
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUser(null);
  };

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <Router>
      <div className="app-layout">
        <Sidebar onLogout={handleLogout} />
        <main className="main-content">
          <Topbar user={user} />
          <div className="page-container">
            <Routes>
              <Route path="/" element={<Checklist />} />
              <Route path="/appointments" element={<Appointments />} />
              <Route path="/patients" element={<Patients />} />
              <Route path="/labs" element={<LabResults />} />
              <Route path="/inventory" element={<Inventory />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/messages" element={<Messages />} />
              <Route path="/staff" element={<StaffDirectory />} />
            </Routes>
          </div>
        </main>
      </div>
    </Router>
  );
}

export default App;
