# System Limitations & Uncertainty Report

This report outlines the known limitations of the Specialty Clinic Medicine Substitution Decision System and how uncertainty is communicated to users.

## 1. Known System Limitations

*   **Mock Data Dependency:** The current system relies on static JSON files to mock external systems (EHR, Inventory). In a production environment, this must be replaced with live API integrations, which may introduce latency or synchronization issues.
*   **Static Rule Engine:** The decision logic is currently hardcoded based on the initial requirements. It lacks a dynamic UI for clinical administrators to add or modify rules without deploying code changes.
*   **Complex Interactions:** The system currently checks for direct one-to-one contraindications and allergies. It does not evaluate complex, multi-drug interaction cascades or cumulative dosage limits across multiple prescriptions.

## 2. Handling Incomplete or Low-Quality Data

The system is designed to "fail safe" when encountering missing or contradictory data.

*   **Missing Patient Allergies:** If the patient's allergy record is explicitly marked "Unknown" or is missing from the payload, the system blocks automatic substitution and flags a **Clinical Warning: Missing Allergy Data**.
*   **Uncertain Stock Levels:** If inventory data is stale (e.g., last updated > 1 hour ago) or missing, the system will flag an **Operational Warning: Unverified Stock**, requiring a physical check confirmation.
*   **Conflicting Data:** If there are conflicting records (e.g., patient is listed as allergic to Amoxicillin but has an active prescription for it), the system suspends automated decision-making and requires a Pharmacist Review.

## 3. Communicating Uncertainty

*   **Clear Categorization:** The UI explicitly separates medical/clinical warnings (Red/Orange alerts) from operational/availability warnings (Blue/Yellow alerts).
*   **Explicit Confidence Levels:** When a substitution is proposed but data is incomplete (e.g., patient weight is missing for a weight-based dosage check), the system explicitly states the missing variable: *“Cannot verify pediatric dosage safety: Patient weight is unrecorded.”*
*   **Mandatory Overrides:** The system forces the human operator to acknowledge the specific uncertainty. The override reason dropdown is dynamically populated based on the type of uncertainty (e.g., "Verified Weight with Patient" vs "Verified Stock on Shelf").

## 4. Reports on Overrides and Blocks

*   **Audit Logging:** Every substitution decision (approved, blocked, or overridden) is logged with the timestamp, user ID, original drug, proposed substitute, and the specific rules that were evaluated.
*   **Override Tracking:** The Metrics Dashboard tracks the frequency and reasons for overrides. High rates of a specific override (e.g., frequent stock overrides) indicate an operational issue that management needs to address.
